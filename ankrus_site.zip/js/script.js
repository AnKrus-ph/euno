document.addEventListener("DOMContentLoaded", () => {
  if (document.getElementById("articles")) loadArticles();
  if (document.getElementById("content")) loadArticle();
});

async function loadArticles() {
  const res = await fetch("posts.json");
  const posts = await res.json();
  const container = document.getElementById("articles");

  posts.forEach(post => {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
      <h2><a href="article.html?id=${post.id}">${post.title}</a></h2>
      <p class="date">${post.date}</p>
      ${post.image ? `<img src="images/${post.image}" alt="">` : ''}
      <p>${post.summary}</p>
    `;
    container.appendChild(card);
  });
}

async function loadArticle() {
  const params = new URLSearchParams(window.location.search);
  const id = params.get("id");

  const res = await fetch("posts.json");
  const posts = await res.json();
  const post = posts.find(p => p.id === id);

  const container = document.getElementById("content");
  if (post) {
    container.innerHTML = `
      <h2>${post.title}</h2>
      <p class="date">${post.date}</p>
      ${post.image ? `<img src="images/${post.image}" alt="">` : ''}
      ${post.content}
    `;
  } else {
    container.innerHTML = "<p>Article not found.</p>";
  }
}